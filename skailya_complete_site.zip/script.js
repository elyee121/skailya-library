
// Gestion des commandes
function commander(idLivre) {
  document.getElementById('form-achat').style.display = 'flex';
  document.getElementById('livreId').value = idLivre;
  document.getElementById('message').textContent = '';
}

function fermerForm() {
  document.getElementById('form-achat').style.display = 'none';
  document.getElementById('formValidation').reset();
  document.getElementById('message').textContent = '';
}

function validerPaiement(event) {
  event.preventDefault();
  const email = document.getElementById('email').value.trim();
  const tel = document.getElementById('tel').value.trim();
  const nomSim = document.getElementById('nomSim').value.trim();
  const numTrans = document.getElementById('numTrans').value.trim();
  const livreId = document.getElementById('livreId').value;

  // Simulation de validation (à remplacer par appel serveur réel)
  if (email && tel && nomSim && numTrans && livreId) {
    // Ici on simule la validation côté serveur
    if (numTrans.length >= 8) {
      document.getElementById('message').textContent = 'Paiement validé. Téléchargement disponible !';
      // TODO: proposer lien téléchargement réel
      setTimeout(() => {
        fermerForm();
        alert('Merci pour votre achat !');
      }, 2000);
      return true;
    } else {
      document.getElementById('message').textContent = 'Numéro de transaction invalide.';
      return false;
    }
  } else {
    document.getElementById('message').textContent = 'Veuillez remplir tous les champs.';
    return false;
  }
}

// Vendeur (simulation)
// TODO: remplacer par vrai backend/authentification
function connecterVendeur(event) {
  event.preventDefault();
  alert('Connexion vendeur simulée.');
  window.location.href = 'dashboard.html';
  return false;
}

function inscrireVendeur(event) {
  event.preventDefault();
  alert('Inscription vendeur simulée.');
  window.location.href = 'dashboard.html';
  return false;
}

function ajouterLivre(event) {
  event.preventDefault();
  alert('Ajout de livre simulé.');
  // Reset form
  document.getElementById('formAjoutLivre').reset();
  return false;
}

function deconnecter() {
  alert('Déconnexion simulée.');
  window.location.href = 'index.html';
}
